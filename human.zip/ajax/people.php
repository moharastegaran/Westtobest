<?php
session_start();
include "../config/config.php";
include '../lang/en.php';
global $conn;

if($_POST['sickness']!='off'||$_POST['country']!='off'||$_POST['city']!='off' ){
    $result=$conn->query("SELECT * FROM user where sickness='".$_POST['sickness']."' or country='".$_POST['country']."'
      or city='".$_POST['city']."' ORDER BY id DESC");

}else{
    $result=$conn->query("SELECT * FROM user ORDER BY id DESC");
}
?>
    <ul class="nearby-contct">
    <?php
     while ($row=mysqli_fetch_assoc($result)){
    if($row['username']!=$_SESSION['username']){
            ?>
        <li>
            <div class="nearly-pepls">
                <figure>
                    <a href="profile.php?p=<?php echo $row['username'];?>" title=""><img src="images/resources/<?php if(empty($row['avatar'])){ echo 'user-avatar.jpg';}else{echo $row['avatar'];}?>" style="width:60px;height:60px" alt=""></a>
                </figure>
                <div class="pepl-info">
                    <h4><a href="profile.php?p=<?php echo $row['username'];?>" title=""><?php echo $row['name'];?></a></h4>
                    <span><?php echo $row['sickness'];?></span>
                    <?php
                    $follow='follow'.$row['id'];
                                        if(isset($_POST[$follow])){
                                            if(mysqli_num_rows($conn->query("SELECT * FROM friend where user_1='".$_SESSION['username']."' and user_2='".$_POST[$follow]."'"))==0){
                                                $conn->query("INSERT INTO friend (user_1,user_2) values ('".$_SESSION['username']."','".$_POST[$follow]."')");
                                                $conn->query("INSERT INTO notfic (user,for_user,notfic) values ('".$_SESSION['username']."','".$_POST[$follow]."','1')");
                                            }else{
                                                $conn->query("DELETE FROM friend where user_1='".$_SESSION['username']."' and user_2='".$_POST[$follow]."'");
                                            }
                                        }
                                        ?>
                    <form action="" method="post" id="follow<?php echo $row['id'];?>">
<input type="hidden" value="<?php echo $row['username']; ?>" name="follow<?php echo $row['id'];?>"/>
</form>
<a href="#" title="" class="add-butn" data-ripple="" onclick="document.getElementById('follow<?php echo $row['id'];?>').submit();">
    <?php if(mysqli_num_rows($conn->query("SELECT * FROM friend where user_1='".$_SESSION['username']."'and user_2='".$row['username']."'"))==0) { echo $lang['follow']; }elseif(mysqli_num_rows($conn->query("SELECT * FROM friend where user_1='".$_SESSION['username']."'and user_2='".$row['username']."' and acc='1'"))!=0){echo $lang['unfollow']; }else{ echo  $lang['request']; }?></a>
                </div>
            </div>
        </li>
<?php } }?>
